/**
 * Sedan is a derived class of Car.
 *
 * It inherits the common attributes and methods
 * from the Car class and adds its own attribute.
 */
public class Sedan extends Car {

    // Unique attribute for Sedan
    private int numberOfDoors;

    /**
     * Constructor for Sedan.
     */
    public Sedan(String carID, String brand, String model,
                 int year, double price, int numberOfDoors) {

        // Call the constructor of the parent class.
        super(carID, brand, model, year, price);

        this.numberOfDoors = numberOfDoors;
    }

    // Getter
    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    // Setter
    public void setNumberOfDoors(int numberOfDoors) {
        this.numberOfDoors = numberOfDoors;
    }

    /**
     * Overrides the parent method.
     *
     * Sedan receives a 10% discount from the basic
     * rental price.
     */
    @Override
    public double calculateRentalPrice(int days) {

        double rental = getPrice() * days;

        return rental * 0.90;
    }

    /**
     * Displays Sedan information.
     */
    @Override
    public void displayCarInfo() {

        System.out.println("Vehicle Type: Sedan");

        super.displayCarInfo();

        System.out.println("Doors       : " + numberOfDoors);
    }
}