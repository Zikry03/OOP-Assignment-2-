/**
 * Booking class represents a customer's car rental booking.
 */
public class Booking {

    private String bookingID;
    private Customer customer;
    private Car car;
    private int rentalDays;
    private double totalPrice;

    /**
     * Constructor for Booking.
     */
    public Booking(String bookingID, Customer customer,
                   Car car, int rentalDays) {

        this.bookingID = bookingID;
        this.customer = customer;
        this.car = car;
        this.rentalDays = rentalDays;

        // Polymorphism happens here.
        // Java automatically uses the overridden
        // calculateRentalPrice() method based on
        // the actual Car object.
        this.totalPrice = car.calculateRentalPrice(rentalDays);
    }

    // Getters

    public String getBookingID() {
        return bookingID;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Car getCar() {
        return car;
    }

    public int getRentalDays() {
        return rentalDays;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    /**
     * Displays complete booking information.
     */
    public void displayBooking() {

        System.out.println("\n========== BOOKING DETAILS ==========");
        System.out.println("Booking ID  : " + bookingID);

        System.out.println("\nCustomer:");
        customer.displayCustomerInfo();

        System.out.println("\nCar:");
        car.displayCarInfo();

        System.out.println("Rental Days : " + rentalDays);
        System.out.printf("Total Price : RM %.2f%n", totalPrice);

        System.out.println("=====================================");
    }
}