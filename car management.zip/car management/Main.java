import java.util.Scanner;

/**
 * Main class for the Car Management System.
 *
 * This class controls the application flow and provides
 * a menu for users to interact with the system.
 */
public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Create the manager object.
        CarManager manager = new CarManager();

        // Create Sedan objects.
        Car sedan1 = new Sedan(
                "C001",
                "Toyota",
                "Camry",
                2022,
                180.00,
                4
        );

        Car sedan2 = new Sedan(
                "C002",
                "Honda",
                "Civic",
                2023,
                160.00,
                4
        );

        // Create SUV objects.
        Car suv1 = new SUV(
                "C003",
                "Toyota",
                "Fortuner",
                2023,
                220.00,
                7
        );

        Car suv2 = new SUV(
                "C004",
                "Honda",
                "CR-V",
                2024,
                200.00,
                5
        );

        // Add cars to the manager.
        manager.addCar(sedan1);
        manager.addCar(sedan2);
        manager.addCar(suv1);
        manager.addCar(suv2);

        int choice;

        // do-while loop keeps the menu running.
        do {

            System.out.println("\n=====================================");
            System.out.println("       CAR MANAGEMENT SYSTEM");
            System.out.println("=====================================");
            System.out.println("1. Display All Cars");
            System.out.println("2. Search Car");
            System.out.println("3. Make Booking");
            System.out.println("4. Demonstrate Polymorphism");
            System.out.println("5. Exit");
            System.out.println("=====================================");

            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            switch (choice) {

                case 1:

                    manager.displayAllCars();
                    break;

                case 2:

                    input.nextLine();

                    System.out.print("Enter Car ID: ");
                    String searchID = input.nextLine();

                    Car foundCar = manager.searchCar(searchID);

                    if (foundCar != null) {

                        System.out.println("\nCar Found:");
                        foundCar.displayCarInfo();

                    } else {

                        System.out.println("Car not found.");
                    }

                    break;

                case 3:

                    input.nextLine();

                    System.out.print("Enter Customer ID: ");
                    String customerID = input.nextLine();

                    System.out.print("Enter Customer Name: ");
                    String name = input.nextLine();

                    System.out.print("Enter Phone Number: ");
                    String phone = input.nextLine();

                    Customer customer =
                            new Customer(customerID, name, phone);

                    System.out.print("Enter Car ID: ");
                    String carID = input.nextLine();

                    Car selectedCar = manager.searchCar(carID);

                    if (selectedCar != null) {

                        System.out.print("Enter Rental Days: ");
                        int days = input.nextInt();

                        if (days > 0) {

                            Booking booking =
                                    new Booking(
                                            "B001",
                                            customer,
                                            selectedCar,
                                            days
                                    );

                            booking.displayBooking();

                        } else {

                            System.out.println(
                                    "Rental days must be greater than 0."
                            );
                        }

                    } else {

                        System.out.println("Car not found.");
                    }

                    break;

                case 4:

                    /*
                     * Polymorphism demonstration.
                     *
                     * Both objects are stored using the Car
                     * reference, but they execute different
                     * overridden calculateRentalPrice()
                     * methods.
                     */

                    Car sedan = new Sedan(
                            "P001",
                            "Toyota",
                            "Camry",
                            2024,
                            180.00,
                            4
                    );

                    Car suv = new SUV(
                            "P002",
                            "Toyota",
                            "Fortuner",
                            2024,
                            220.00,
                            7
                    );

                    int rentalDays = 3;

                    System.out.println(
                            "\nPOLYMORPHISM DEMONSTRATION"
                    );

                    System.out.printf(
                            "Sedan rental for %d days: RM %.2f%n",
                            rentalDays,
                            sedan.calculateRentalPrice(rentalDays)
                    );

                    System.out.printf(
                            "SUV rental for %d days: RM %.2f%n",
                            rentalDays,
                            suv.calculateRentalPrice(rentalDays)
                    );

                    break;

                case 5:

                    System.out.println(
                            "Thank you for using the Car Management System."
                    );

                    break;

                default:

                    System.out.println(
                            "Invalid choice. Please try again."
                    );
            }

        } while (choice != 5);

        input.close();
    }
}