/**
 * Customer class stores information about the customer.
 *
 * Encapsulation is applied using private attributes.
 */
public class Customer {

    private String customerID;
    private String name;
    private String phoneNumber;

    /**
     * Constructor for Customer.
     */
    public Customer(String customerID, String name,
                    String phoneNumber) {

        this.customerID = customerID;
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    // Getters and setters

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * Displays customer information.
     */
    public void displayCustomerInfo() {

        System.out.println("Customer ID : " + customerID);
        System.out.println("Name        : " + name);
        System.out.println("Phone       : " + phoneNumber);
    }
}