import java.util.ArrayList;

/**
 * CarManager manages the collection of cars.
 *
 * It demonstrates the use of loops and selection
 * statements when managing the system.
 */
public class CarManager {

    private ArrayList<Car> cars;

    /**
     * Constructor creates an empty list of cars.
     */
    public CarManager() {
        cars = new ArrayList<>();
    }

    /**
     * Adds a car into the system.
     */
    public void addCar(Car car) {
        cars.add(car);
    }

    /**
     * Displays all cars in the system.
     */
    public void displayAllCars() {

        if (cars.isEmpty()) {

            System.out.println("No cars are available.");

        } else {

            System.out.println("\n========== AVAILABLE CARS ==========");

            // Loop through every car.
            for (Car car : cars) {

                car.displayCarInfo();

                System.out.println("-------------------------------------");
            }
        }
    }

    /**
     * Searches for a car using its ID.
     */
    public Car searchCar(String carID) {

        // Enhanced for loop checks every car.
        for (Car car : cars) {

            if (car.getCarID().equalsIgnoreCase(carID)) {
                return car;
            }
        }

        return null;
    }

    /**
     * Returns the number of cars.
     */
    public int getCarCount() {
        return cars.size();
    }
}