/**
 * SUV is another derived class of Car.
 *
 * It inherits from Car and adds its own unique attribute.
 */
public class SUV extends Car {

    // Unique attribute for SUV
    private int seatingCapacity;

    /**
     * Constructor for SUV.
     */
    public SUV(String carID, String brand, String model,
               int year, double price, int seatingCapacity) {

        super(carID, brand, model, year, price);

        this.seatingCapacity = seatingCapacity;
    }

    // Getter
    public int getSeatingCapacity() {
        return seatingCapacity;
    }

    // Setter
    public void setSeatingCapacity(int seatingCapacity) {
        this.seatingCapacity = seatingCapacity;
    }

    /**
     * Overrides calculateRentalPrice().
     *
     * SUV rental price is increased by 15%
     * because of its larger capacity.
     */
    @Override
    public double calculateRentalPrice(int days) {

        double rental = getPrice() * days;

        return rental * 1.15;
    }

    /**
     * Displays SUV information.
     */
    @Override
    public void displayCarInfo() {

        System.out.println("Vehicle Type: SUV");

        super.displayCarInfo();

        System.out.println("Seats       : " + seatingCapacity);
    }
}