/**
 * Rentable interface
 * Defines the common behaviour that rental vehicles should have.
 */
public interface Rentable {

    // Every rentable vehicle must calculate its rental price.
    double calculateRentalPrice(int days);
}