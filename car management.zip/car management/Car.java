/**
 * Base class for the Car Management System.
 *
 * This class stores common information shared by different
 * types of cars.
 *
 * Encapsulation is applied by declaring all attributes as private.
 */
public class Car implements Rentable {

    // Private attributes protect the car's data.
    private String carID;
    private String brand;
    private String model;
    private int year;
    private double price;

    /**
     * Constructor used to initialise a Car object.
     */
    public Car(String carID, String brand, String model,
               int year, double price) {

        this.carID = carID;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.price = price;
    }

    // Getter for car ID
    public String getCarID() {
        return carID;
    }

    // Setter for car ID
    public void setCarID(String carID) {
        this.carID = carID;
    }

    // Getter for brand
    public String getBrand() {
        return brand;
    }

    // Setter for brand
    public void setBrand(String brand) {
        this.brand = brand;
    }

    // Getter for model
    public String getModel() {
        return model;
    }

    // Setter for model
    public void setModel(String model) {
        this.model = model;
    }

    // Getter for year
    public int getYear() {
        return year;
    }

    // Setter for year
    public void setYear(int year) {
        this.year = year;
    }

    // Getter for price
    public double getPrice() {
        return price;
    }

    // Setter for price
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Displays the basic information of a car.
     */
    public void displayCarInfo() {

        System.out.println("Car ID      : " + carID);
        System.out.println("Brand       : " + brand);
        System.out.println("Model       : " + model);
        System.out.println("Year        : " + year);
        System.out.printf("Price       : RM %.2f%n", price);
    }

    /**
     * Default rental calculation.
     *
     * This method can be overridden by subclasses.
     */
    @Override
    public double calculateRentalPrice(int days) {
        return price * days;
    }
}